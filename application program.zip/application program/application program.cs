
using System;

class Program
{
    static void Main()
    {
        // Define the 2D array with the given data
        string[,] animals = new string[,]
        {
            { "Dog", "Male", "White", "500" },
            { "Cat", "Female", "Black", "150" },
            { "Pig", "Female", "Pink", "400" },
            { "Cow", "Male", "Red", "350" },
            { "Chicken", "Female", "Brown", "600" },
            { "Goat", "Male", "White", "550" },
            { "Sheep", "Female", "White", "450" }
        };

        // Print the header
        Console.WriteLine("Animal\tGender\tColor\tPrice");

        // Loop through the 2D array and print each row
        for (int i = 0; i < animals.GetLength(0); i++)
        {
            for (int j = 0; j < animals.GetLength(1); j++)
            {
                Console.Write(animals[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}


